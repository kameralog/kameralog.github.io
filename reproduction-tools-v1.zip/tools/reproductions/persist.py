import argparse,json,pathlib,shutil
from common import atomic
ALLOWED=('state.json','progress.json','verification-progress.json','pipeline-run.json','http-cooldown.json')
def persist(payload,dest):
    payload=pathlib.Path(payload).resolve();dest=pathlib.Path(dest);dest.mkdir(parents=True,exist_ok=True);count=0
    candidates=[payload/n for n in ALLOWED if (payload/n).exists()]
    if (payload/'report').is_dir():candidates.extend((payload/'report').rglob('*.json'))
    for p in candidates:
        if p.is_symlink() or not p.resolve().is_relative_to(payload) or p.stat().st_size>33554432:raise ValueError('Invalid checkpoint file')
        rel=p.relative_to(payload)
        if '..' in rel.parts:raise ValueError('Unsafe checkpoint path')
        value=json.loads(p.read_text('utf-8'));atomic(dest/rel,value);count+=1
    if not count:raise ValueError('No checkpoint was produced; preserve previous state')
    return count
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('payload');p.add_argument('dest');a=p.parse_args();print(persist(a.payload,a.dest))
