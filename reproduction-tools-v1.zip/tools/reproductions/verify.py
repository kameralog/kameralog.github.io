import argparse,collections,io,json,pathlib,re,shutil,time
from common import *
from collect import export,target_fp,report
import adapters
QUALIFIERS=re.compile(r'\b(after|circle|workshop|follower|attributed|school|manner|copy)\b',re.I)
def creator_ok(task,c):
    creators=c.get('creators',[])
    if len(creators)!=1 or c.get('qualifier') or task.get('attribution') or QUALIFIERS.search(creators[0] if creators else ''):return False
    name=re.sub(r'\([^)]*\)','',creators[0]).strip()
    return norm(name) in {norm(n) for n in task.get('aliases',[]) if n}
def fresh_candidate(task,c,http):
    if c['provider'] in ('met','aic','cma'):
        fresh=adapters.lookup(task,http)
        return next((x for x in fresh if x['provider']==c['provider'] and x['objectId']==c['objectId'] and urlkey(x['image'])==urlkey(c['image'])),None)
    if c['provider']=='commons':
        if not c.get('fileTitle','').startswith('File:'):return None
        x,entry=http.json(adapters.endpoint('https://commons.wikimedia.org/w/api.php',{'action':'query','format':'json','formatversion':2,'titles':c['fileTitle'],'redirects':1,'prop':'imageinfo','iiprop':'url|size|extmetadata','iiurlwidth':960}))
        pages=[p for p in x.get('query',{}).get('pages',[]) if p.get('imageinfo')]
        return adapters.commons_page(task,pages[0],entry) if len(pages)==1 else None
    return c

def check(task,c,http,decision=None):
    fresh=fresh_candidate(task,c,http)
    if not fresh:return {'status':'needs_review','reason':'source_or_file_changed'}
    lic=fresh['rights']
    if not lic.get('documentedOpen'):return {'status':'blocked_rights','reason':'No sufficient image-specific license evidence','candidateId':fresh['id']}
    if fresh.get('qualifier') or (fresh.get('provider') in ('met','aic','cma') and any(QUALIFIERS.search(n) for n in fresh.get('creators',[]))):return {'status':'needs_editorial','reason':'Attribution must be displayed explicitly before media import'}
    if re.search(r'\b(detail|fragment|verso|reverse|nachfolger|follower|copy|after)\b',str(fresh.get('title','')).replace('_',' '),re.I):return {'status':'needs_editorial','reason':'Copy, partial view or reverse needs explicit editorial handling'}
    if not fresh.get('image'):return {'status':'no_image_in_source','candidateId':fresh['id']}
    preview=http.image(fresh['image']);previous=c.get('_verifiedSha')
    if previous and previous!=preview['sha']:return {'status':'needs_review','reason':'image_bytes_changed','candidateId':fresh['id']}
    c['_verifiedSha']=preview['sha']
    strict=fresh['basis']=='museum-primary' and creator_ok(task,fresh) and fresh['view']=='primary'
    reviewed=bool(decision and decision.get('identityApproved') is True and decision.get('candidateId')==fresh['id'] and decision.get('assetSha256')==preview['sha'] and urlkey(decision.get('reviewedObjectURL'))==urlkey(task['source']) and decision.get('reviewer') and decision.get('evidenceURLs'))
    if not strict and not reviewed:return {'status':'needs_review','reason':'Identity/view needs an independent decision','candidateId':fresh['id'],'preview':preview,'rights':lic}
    if not task.get('workKey'):return {'status':'needs_editorial','reason':'A stable work key is required','candidateId':fresh['id'],'preview':preview}
    if task.get('owner')=='index.html':return {'status':'needs_target_integration','reason':'Initial ARTISTS is read-only in v1','candidateId':fresh['id'],'preview':preview}
    zoom=preview
    if fresh.get('zoom') and urlkey(fresh['zoom'])!=urlkey(fresh['image']):
        try:zoom=http.image(fresh['zoom'])
        except Deferred:raise
        except Exception:pass
    return {'status':'ready','candidateId':fresh['id'],'preview':preview,'zoom':zoom,'rights':lic,'candidate':fresh,'identityBasis':'museum_api_primary_resource' if strict else 'explicit_identity_review','visualReview':False,'reviewDecision':decision if reviewed else None}
def _prepare(work,policy,decisions=None,http=None):
    work=pathlib.Path(work);http=http or HTTP(policy,work);decisions=decisions or {}
    with locked(work):
        state=read(work/'state.json');assert state and state['schemaVersion']==1
        entries=[];assets={};out=work/'package';out.mkdir(exist_ok=True);(out/'assets').mkdir(exist_ok=True)
        for id,item in state['tasks'].items():
            if item['status'] not in ('collected','deferred') or not item.get('candidates'):continue
            results=[]
            for c in item['candidates']:
                try:r=check(item['task'],c,http,decisions.get(id))
                except Deferred as e:r={'status':'deferred','reason':str(e),'nextAttemptAt':e.retry_at}
                except Exception as e:r={'status':'verification_failed','reason':str(e)}
                results.append(r)
                if r['status']=='ready':
                    task=item['task'];fresh=r['candidate'];lic=r['rights'];credit='; '.join(dict.fromkeys(x for x in [lic['author'],lic['credit'],lic['name']] if x))
                    entry={'taskId':id,'artistId':task['artistId'],'workKey':task['workKey'],'expectedSource':task['source'],'targetFingerprint':item['fingerprint'],'imageSource':fresh['source'],'license':lic['name'],'licenseURL':lic['uri'],'creditLine':credit,'identityBasis':r['identityBasis'],'preview':r['preview'],'zoom':r['zoom'],'evidence':fresh['evidence'],'reviewDecision':r['reviewDecision']}
                    entries.append(entry)
                    for asset in [r['preview'],r['zoom']]:
                        sha=asset['sha'];data=blob_path(work,sha).read_bytes();assert digest(data)==sha
                        (out/'assets'/sha).write_bytes(data);assets[sha]={'sha256':sha,'size':len(data),'format':asset['format']}
                    break
            item['verification']={'status':'ready' if any(x['status']=='ready' for x in results) else results[-1]['status'] if results else 'no_candidates','results':results,'checkedAt':time.time()};atomic(work/'state.json',state)
        # Asset directory is intentionally not cleaned: immutable prior package bytes may still be referenced.
        package={'schemaVersion':1,'kind':'verified-reproduction-package','sourceSnapshot':state['snapshot'],'policyHash':fingerprint(policy),'createdAt':time.time(),'entries':entries,'assets':list(assets.values()),'applicationFilesModified':False}
        atomic(out/'manifest.json',package);sha=digest((out/'manifest.json').read_bytes());chunks(work/'report/packages'/sha,package['entries']);atomic(work/'report/package.json',{'schemaVersion':1,'ready':len(entries),'packageSha256':sha,'manifest':'package/manifest.json','sourceSnapshot':state['snapshot']});report(work,state)
        return package,sha

def prepare(work,policy,decisions=None,http=None):
    work=pathlib.Path(work);atomic(work/'verification-progress.json',{'status':'running','at':time.time()})
    try:
        package,sha=_prepare(work,policy,decisions,http)
        atomic(work/'verification-progress.json',{'status':'completed','ready':len(package['entries']),'packageSha256':sha,'at':time.time()})
        return package,sha
    except BaseException as e:
        atomic(work/'verification-progress.json',{'status':'failed','error':str(e),'at':time.time()});raise

def safe_under(repo,path):
    r=pathlib.Path(repo).resolve();original=pathlib.Path(path).absolute();p=original.resolve()
    if not p.is_relative_to(r):raise ValueError('Path escapes repository')
    current=r
    for part in original.relative_to(r).parts:
        current=current/part
        if current.is_symlink():raise ValueError('Symlinks are not allowed for generated paths')
    return p

def apply(package_dir,repo,expected_sha,policy,catalogue=None):
    p=pathlib.Path(package_dir).resolve();raw=(p/'manifest.json').read_bytes()
    if not re.fullmatch('[a-f0-9]{64}',expected_sha) or digest(raw)!=expected_sha:raise ValueError('Package fingerprint mismatch')
    pkg=json.loads(raw)
    if pkg.get('schemaVersion')!=1 or pkg.get('kind')!='verified-reproduction-package' or pkg.get('policyHash')!=fingerprint(policy):raise ValueError('Unsupported package/policy')
    age=time.time()-pkg.get('createdAt',0)
    if age<0 or age>policy.get('packageMaxHours',24)*3600:raise Conflict('Package expired; refresh source verification and approve the new fingerprint')
    repo=pathlib.Path(repo).resolve();builder=repo/'games/painting/build-artists.mjs'
    if 'reproduction-pipeline:hook-v1' not in builder.read_text('utf-8'):raise Conflict('Install the one-time build hook before applying media')
    cat=catalogue or export(repo);records={(r['artistId'],r['workKey']):r for r in cat['records']};registry_path=safe_under(repo,repo/'games/painting/data/reproductions/registry.json');registry=read(registry_path,{'schemaVersion':1,'entries':[]})
    if registry.get('schemaVersion')!=1:raise ValueError('Unsupported media registry')
    current={(e['artistId'],e['workKey']):e for e in registry['entries']};assert len(current)==len(registry['entries']),'Duplicate registry entries';seen=set();planned=[];writes=[]
    for entry in pkg['entries']:
        key=(entry['artistId'],entry['workKey'])
        if not re.fullmatch('[A-Za-z0-9_-]+',key[0]) or key[0] in ('__proto__','constructor','prototype') or not isinstance(key[1],str) or not key[1]:raise ValueError('Invalid target identity')
        if key in seen:raise ValueError('Duplicate package target')
        seen.add(key);target=records.get(key)
        if not target or target.get('owner')=='index.html':raise Conflict('Missing/unsupported current target')
        images=[]
        for a in [entry['preview'],entry['zoom']]:
            sha=a['sha'];asset=p/'assets'/sha
            if not re.fullmatch('[a-f0-9]{64}',sha) or asset.is_symlink() or not asset.resolve().is_relative_to(p):raise ValueError('Unsafe package asset')
            data=asset.read_bytes()
            if digest(data)!=sha:raise ValueError('Asset fingerprint mismatch')
            from PIL import Image
            if len(data)>policy['maxImageBytes']:raise ValueError('Package asset exceeds byte limit')
            with Image.open(io.BytesIO(data)) as im:
                if im.width*im.height>80000000 or im.width<policy['minWidth'] or im.height<policy['minHeight']:raise ValueError('Package image dimensions violate policy')
                im.load();extension={'JPEG':'jpg','PNG':'png','WEBP':'webp'}.get(im.format)
                if not extension:raise ValueError('Unsupported package image')
            relative='assets/reproductions/'+sha+'.'+extension;dest=safe_under(repo,repo/'games/painting'/relative);images.append(relative);writes.append((dest,data))
        old=current.get(key)
        if old:
            if old['image']==images[0] and old['zoom']==images[1] and old['expectedSource']==entry['expectedSource']:continue
            raise Conflict('Existing media registry entry requires explicit replacement review')
        if target_fp(target)!=entry['targetFingerprint'] or target.get('image'):raise Conflict('Current media/source/author changed; refresh this target')
        media={k:entry[k] for k in ['artistId','workKey','expectedSource','imageSource','license','licenseURL','creditLine','identityBasis']};media.update(image=images[0],zoom=images[1],width=entry['preview']['width'],height=entry['preview']['height'],packageSha256=expected_sha)
        planned.append(media)
    # All guards run before application writes; unreferenced immutable assets are harmless after interruption.
    for dest,data in writes:
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists() and dest.read_bytes()!=data:raise Conflict('Content-addressed asset differs')
        if not dest.exists():tmp=dest.with_name(dest.name+'.tmp');tmp.write_bytes(data);tmp.replace(dest)
    if planned:atomic(registry_path,{'schemaVersion':1,'entries':registry['entries']+planned})
    return {'added':len(planned),'unchanged':len(pkg['entries'])-len(planned),'applicationRegistry':str(registry_path.relative_to(repo)),'sourceBatchFilesModified':False,'quizCardsModified':False,'built':False,'published':False}
if __name__=='__main__':
    p=argparse.ArgumentParser();s=p.add_subparsers(dest='command',required=True)
    a=s.add_parser('prepare');a.add_argument('--work',default='reproduction-state');a.add_argument('--decisions');a.add_argument('--policy',default=str(ROOT/'policy.json'))
    a=s.add_parser('apply');a.add_argument('--package',required=True);a.add_argument('--repo',required=True);a.add_argument('--expected-sha',required=True);a.add_argument('--policy',default=str(ROOT/'policy.json'))
    args=p.parse_args();policy=read(args.policy)
    if args.command=='prepare':pkg,sha=prepare(args.work,policy,read(args.decisions,{}) if args.decisions else {});print(json.dumps({'ready':len(pkg['entries']),'packageSha256':sha}))
    else:print(json.dumps(apply(args.package,args.repo,args.expected_sha,policy)))
