import json,re,urllib.parse as up
from html.parser import HTMLParser
from common import plain,urlkey,fingerprint
MUSEUMS={'metmuseum.org':'met','artic.edu':'aic','clevelandart.org':'cma','uffizi.it':'uffizi','museidigenova.it':'genoa','museodelprado.es':'prado','rijksmuseum.nl':'rijks','nationalgallery.org.uk':'london'}
def museum(source):
    try:
        host=up.urlsplit(source).hostname or ''
        if up.urlsplit(source).path.lower().endswith('.pdf'):return 'catalogues'
        if (host=='uffizi.it' or host.endswith('.uffizi.it')) and '/events/' in up.urlsplit(source).path:return 'uffizi-references'
        return next((v for k,v in MUSEUMS.items() if host==k or host.endswith('.'+k)),'other')
    except ValueError:return 'other'
def endpoint(base,params):return base+'?'+up.urlencode(params)
def rights(name='',uri='',author='',credit='',restriction='',evidence=''):
    name=plain(name);uri=plain(uri)
    free=name in ('CC0','Public domain','Public Domain Mark','CC0 1.0') or bool(re.fullmatch(r'CC BY(?:-SA)? [234]\.0',name) and author and re.match(r'https?://creativecommons\.org/licenses/by(?:-sa)?/[234]\.0/?$',uri))
    return {'name':name,'uri':uri,'author':plain(author),'credit':plain(credit),'restrictions':plain(restriction),'evidenceURL':evidence,'documentedOpen':bool(free and not restriction and str(evidence).startswith('https://'))}
def candidate(task,provider,obj,source,image,zoom,title,creators,licence,entry,basis,qualifier='',view='unknown'):
    return {'id':fingerprint([provider,str(obj),urlkey(image)]),'taskId':task['id'],'provider':provider,'objectId':str(obj),'source':source,'image':image,'zoom':zoom or image,'title':title,'creators':creators,'qualifier':qualifier,'view':view,'rights':licence,'basis':basis,'evidence':{'url':entry['url'],'sha256':entry['sha'],'checkedAt':entry['at']}}
def lookup(task,http):
    source=task.get('source','');host=up.urlsplit(source).hostname or '';path=up.urlsplit(source).path
    if host in ('www.metmuseum.org','metmuseum.org') and (m:=re.search(r'/collection/search/(\d+)',path)):
        x,entry=http.json('https://collectionapi.metmuseum.org/public/collection/v1/objects/'+m[1]);assert str(x.get('objectID'))==m[1]
        if not x.get('primaryImage'):return []
        lic=rights('CC0' if x.get('isPublicDomain') is True else '', 'https://creativecommons.org/publicdomain/zero/1.0/' if x.get('isPublicDomain') is True else '',x.get('artistDisplayName'),x.get('creditLine'),evidence='https://www.metmuseum.org/about-the-met/policies-and-documents/open-access')
        return [candidate(task,'met',m[1],source,x.get('primaryImageSmall') or x['primaryImage'],x['primaryImage'],x.get('title',''),[x.get('artistDisplayName','')],lic,entry,'museum-primary',qualifier=' '.join(filter(None,[x.get('artistPrefix'),x.get('artistSuffix')])),view='primary')]
    if host in ('www.artic.edu','artic.edu') and (m:=re.search(r'/artworks/(\d+)',path)):
        x,entry=http.json('https://api.artic.edu/api/v1/artworks/'+m[1]);d=x['data'];assert str(d['id'])==m[1]
        if not d.get('image_id'):return []
        base=x['config']['iiif_url'].rstrip('/')+'/'+up.quote(d['image_id'])
        lic=rights('CC0' if d.get('is_public_domain') is True else '','https://creativecommons.org/publicdomain/zero/1.0/' if d.get('is_public_domain') is True else '',d.get('artist_title'),d.get('credit_line'),evidence='https://www.artic.edu/open-access/open-access-policy')
        return [candidate(task,'aic',m[1],source,base+'/full/843,/0/default.jpg',base+'/full/1686,/0/default.jpg',d.get('title',''),d.get('artist_titles') or [d.get('artist_title') or plain(d.get('artist_display'))],lic,entry,'museum-primary',qualifier=plain(d.get('artist_display')) if re.search(r'\b(after|circle|workshop|follower|attributed|school|manner|copy)\b',plain(d.get('artist_display')),re.I) else '',view='primary')]
    if host in ('www.clevelandart.org','clevelandart.org') and (m:=re.search(r'/art/([^/]+)',path)):
        x,entry=http.json('https://openaccess-api.clevelandart.org/api/artworks/'+up.quote(m[1],safe=''));d=x['data']
        if str(d.get('id'))!=m[1] and d.get('accession_number')!=m[1]:raise ValueError('CMA accession mismatch')
        im=d.get('images',{});preview=im.get('web',{}).get('url');zoom=im.get('print',{}).get('url') or preview
        if not preview:return []
        creators=[c.get('name') or re.sub(r'\s*\([^)]*\)','',c.get('description','')).strip() for c in d.get('creators',[])]
        lic=rights('CC0' if d.get('share_license_status')=='CC0' else '', 'https://creativecommons.org/publicdomain/zero/1.0/' if d.get('share_license_status')=='CC0' else '', '; '.join(creators),d.get('creditline'),evidence=d.get('url') or source)
        return [candidate(task,'cma',d['id'],source,preview,zoom,d.get('title',''),creators,lic,entry,'museum-primary',qualifier='; '.join(c.get('description','') for c in d.get('creators',[]) if re.search(r'\b(after|circle|workshop|follower|attributed|school|manner|copy)\b',c.get('description',''),re.I)),view='primary')]
    return []
class Page(HTMLParser):
    def __init__(self):super().__init__();self.meta={};self.manifests=[];self.links=[];self.script=False;self.parts=[];self.jsonld=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='meta':self.meta[a.get('property') or a.get('name','')]=a.get('content','')
        if tag=='link' and 'manifest' in a.get('rel',''):self.manifests.append(a.get('href',''))
        if tag=='script' and a.get('type')=='application/ld+json':self.script=True;self.parts=[]
        if tag=='a' and a.get('href'):self.links.append(a['href'])
    def handle_data(self,s):
        if self.script:self.parts.append(s)
    def handle_endtag(self,tag):
        if tag=='script' and self.script:
            try:self.jsonld.append(json.loads(''.join(self.parts)))
            except ValueError:pass
            self.script=False
def page_candidates(task,http):
    if museum(task.get('source','')) not in ('uffizi','genoa','prado','rijks','london'):return []
    raw,entry=http.get(task['source']);p=Page();p.feed(raw.decode('utf-8','replace'));images=[]
    if p.meta.get('og:image'):images.append(p.meta['og:image'])
    def walk(v):
        if isinstance(v,dict):
            if v.get('@type') in ('VisualArtwork','Painting','CreativeWork'):
                im=v.get('image');images.extend([im] if isinstance(im,str) else [im['url']] if isinstance(im,dict) and im.get('url') else [i for i in im or [] if isinstance(i,str)] if isinstance(im,list) else [])
            for w in v.values():walk(w)
        elif isinstance(v,list):
            for w in v:walk(w)
    for item in p.jsonld:walk(item)
    out=[]
    for image in dict.fromkeys(images):
        image=up.urljoin(task['source'],image)
        out.append(candidate(task,museum(task['source']),task.get('workKey') or task['source'],task['source'],image,image,p.meta.get('og:title') or task.get('title',''),[],rights(evidence=task['source']),entry,'page-candidate'))
    for manifest in dict.fromkeys(p.manifests):
        try:out.extend(iiif_candidates(task,up.urljoin(task['source'],manifest),http))
        except Exception:pass
    return out
def iiif_candidates(task,manifest_url,http):
    m,entry=http.json(manifest_url);out=[]
    canvases=m.get('items') or (m.get('sequences') or [{}])[0].get('canvases',[])
    for canvas in canvases[:6]:
        annotations=[a for page in canvas.get('items',[]) for a in page.get('items',[])] or canvas.get('images',[])
        for a in annotations:
            body=a.get('body') or a.get('resource') or {};body=body[0] if isinstance(body,list) and body else body
            image=body.get('id') or body.get('@id')
            if not image or not str(body.get('type') or body.get('@type','')).lower().endswith('image'):continue
            uri=body.get('rights') or body.get('license') or '';name='CC0' if '/publicdomain/zero/1.0' in uri else 'Public domain' if '/publicdomain/mark/1.0' in uri else ''
            label=canvas.get('label','');label=' '.join(str(x) for vs in label.values() for x in (vs if isinstance(vs,list) else [vs])) if isinstance(label,dict) else str(label)
            credit=plain((m.get('requiredStatement') or {}).get('value',''))
            out.append(candidate(task,'iiif',canvas.get('id') or canvas.get('@id'),task['source'],image,image,label,[],rights(name,uri,credit=credit,evidence=manifest_url),entry,'manifest-candidate',view=label))
    return out
def commons(task,http):
    q='"'+str(task.get('aliases',[''])[0]).replace('"','')+'" '+(task.get('originalTitle') or task.get('title',''))
    x,entry=http.json(endpoint('https://commons.wikimedia.org/w/api.php',{'action':'query','format':'json','formatversion':2,'generator':'search','gsrnamespace':6,'gsrlimit':5,'gsrsearch':q[:240],'prop':'imageinfo','iiprop':'url|size|sha1|extmetadata','iiurlwidth':960}))
    return [commons_page(task,p,entry) for p in x.get('query',{}).get('pages',[]) if p.get('imageinfo')]
def commons_page(task,p,entry):
    ii=p['imageinfo'][0];meta=ii.get('extmetadata',{});v=lambda k:plain(meta.get(k,{}).get('value',''))
    lic=rights(v('LicenseShortName'),v('LicenseUrl'),v('Artist'),'; '.join(filter(None,[v('Attribution'),v('Credit'),v('Copyright')])),v('Restrictions'),ii.get('descriptionurl',''))
    c=candidate(task,'commons',p['title'],ii.get('descriptionurl',''),ii.get('thumburl') or ii['url'],ii['url'],v('ObjectName') or p['title'],[v('Artist')],lic,entry,'commons-candidate');c['fileTitle']=p['title'];return c
