import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const repo=path.resolve(process.argv[2]||'.'),file=path.join(repo,'games/painting/build-artists.mjs'),moduleFile=path.join(repo,'tools/reproductions/site-overlay.mjs');assert(fs.existsSync(moduleFile),'Install the module in tools/reproductions first');let source=fs.readFileSync(file,'utf8');const marker='/*reproduction-pipeline:hook-v1*/';if(source.includes(marker)){console.log('Build hook already installed');process.exit(0);}
function once(a,b){assert.equal(source.split(a).length,2,'Build anchor changed: '+a);source=source.replace(a,()=>b);}
source=marker+"\nimport {readMedia,mergeMedia,composeMediaBundle} from '../../tools/reproductions/site-overlay.mjs';\n"+source;
once('const errors=[],ids=new Map(),keys=new Map(),aliases=new Map();',"const MEDIA=readMedia('data/reproductions/registry.json');\nconst errors=[],ids=new Map(),keys=new Map(),aliases=new Map();");
once('sandbox.registerPaintingArtists=b=>batches.push(b);','sandbox.registerPaintingArtists=b=>batches.push(mergeMedia(b,MEDIA));');
once("const out=files.map(f=>`/* ${f} */\\n${fs.readFileSync(f,'utf8')}\\n;`).join('\\n');","for(const e of MEDIA)if(!ids.has(e.artistId))throw Error('Media targets an unsupported initial/missing artist: '+e.artistId);\nconst out=composeMediaBundle(files.map(f=>`/* ${f} */\\n${fs.readFileSync(f,'utf8')}\\n;`).join('\\n'),MEDIA);");
fs.writeFileSync(file,source);console.log('One build hook installed; no batch or quiz data edited.');
