import contextlib, datetime as dt, hashlib, html, ipaddress, json, os, pathlib, re, time, urllib.parse as up, urllib.request as ur, urllib.error as ue
from email.utils import parsedate_to_datetime
ROOT=pathlib.Path(__file__).resolve().parent
class Deferred(Exception):
    def __init__(self,message,retry_at): super().__init__(message);self.retry_at=retry_at
class Conflict(Exception): pass
def digest(data): return hashlib.sha256(data).hexdigest()
def encoded(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def fingerprint(x): return digest(encoded(x))
def read(path,default=None):
    try:return json.loads(pathlib.Path(path).read_text('utf-8'))
    except FileNotFoundError:return default
def atomic(path,value):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp');tmp.write_bytes(encoded(value));os.replace(tmp,p)
def norm(x):
    import unicodedata
    return ''.join(c for c in unicodedata.normalize('NFKD',str(x)).casefold() if c.isalnum() and not unicodedata.combining(c))
def plain(x): return re.sub(r'\s+',' ',re.sub('<[^>]*>',' ',html.unescape(str(x or '')))).strip()
def urlkey(x):
    try:
        u=up.urlsplit(x);q=[(k,v) for k,v in up.parse_qsl(u.query) if not k.startswith('utm_')]
        return up.urlunsplit((u.scheme.lower(),u.netloc.lower(),u.path,up.urlencode(q),''))
    except (TypeError,ValueError):return ''
def blob_path(work,sha):
    if not re.fullmatch('[a-f0-9]{64}',str(sha)):raise ValueError('Invalid asset hash')
    return pathlib.Path(work)/'blobs'/sha
def locked(work):
    import fcntl
    @contextlib.contextmanager
    def lock():
        p=pathlib.Path(work);p.mkdir(parents=True,exist_ok=True)
        with (p/'.lock').open('a') as f:
            try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise Conflict('Another process owns this queue')
            try:yield
            finally:fcntl.flock(f,fcntl.LOCK_UN)
    return lock()
def validate_url(url,policy):
    u=up.urlsplit(url)
    if u.scheme!='https' or u.username or u.password or u.port not in (None,443) or u.hostname not in policy['allowedHosts']:raise ValueError('Destination is not an approved HTTPS host: '+str(url))
    return urlkey(url)
def retry_seconds(value,now):
    if value:
        try:return max(0,float(value))
        except ValueError:
            try:return max(0,parsedate_to_datetime(value).timestamp()-now)
            except (TypeError,ValueError,OverflowError):pass
    return 60
class NoRedirect(ur.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
class HTTP:
    def __init__(self,policy,work,transport=None,clock=time.time,sleep=time.sleep):
        self.policy=policy;self.work=pathlib.Path(work);self.clock=clock;self.sleep=sleep;self.end=clock()+policy['seconds'];self.count=0;self.next_api=0;self.next_image=0;self.cooldown=read(self.work/'http-cooldown.json',{}).get('until',0);self.cache=read(self.work/'http-cache.json',{});self.transport=transport or self._open
    def _open(self,url,headers,limit):
        req=ur.Request(url,headers=headers)
        try:r=ur.build_opener(NoRedirect).open(req,timeout=max(1,min(30,self.end-self.clock())))
        except ue.HTTPError as e:r=e
        with r:
            h={k.lower():v for k,v in r.headers.items()};body=r.read(limit+1)
            if len(body)>limit:raise ValueError('Response exceeds byte limit')
            return r.status,h,body
    def get(self,url,image=False,refresh=False):
        url=validate_url(url,self.policy);key=fingerprint({'url':url,'image':image});old=self.cache.get(key);now=self.clock()
        if not refresh and old and now-old['at']<self.policy['cacheHours']*3600:
            p=blob_path(self.work,old['sha'])
            if p.exists() and digest(p.read_bytes())==old['sha']:return p.read_bytes(),old
        for attempt in range(3):
            slot=max(self.clock(),self.cooldown,self.next_image if image else self.next_api)
            if self.count>=self.policy['maxRequests'] or slot>=self.end:raise Deferred('Request deferred by time/request budget',max(slot,self.clock()+60))
            if slot>self.clock():self.sleep(slot-self.clock())
            self.count+=1
            if image:self.next_image=self.clock()+self.policy['imageInterval']
            else:self.next_api=self.clock()+self.policy['apiInterval']
            try:status,headers,body=self.transport(url,{'User-Agent':self.policy['userAgent'],'Accept':'image/*' if image else 'application/json,text/html'},self.policy['maxImageBytes'] if image else 5242880)
            except (OSError,TimeoutError) as e:
                if attempt==2:raise Deferred(str(e),self.clock()+300)
                self.cooldown=max(self.cooldown,self.clock()+2**attempt);continue
            if status in (301,302,303,307,308):
                for _ in range(3):
                    url=validate_url(up.urljoin(url,headers.get('location','')),self.policy)
                    self.count+=1
                    if self.count>self.policy['maxRequests']:raise Deferred('Redirect budget exhausted',self.clock()+60)
                    status,headers,body=self.transport(url,{'User-Agent':self.policy['userAgent'],'Accept':'image/*' if image else 'application/json,text/html'},self.policy['maxImageBytes'] if image else 5242880)
                    if status not in (301,302,303,307,308):break
            if status in (429,500,502,503,504):
                self.cooldown=max(self.cooldown,self.clock()+retry_seconds(headers.get('retry-after'),self.clock()));atomic(self.work/'http-cooldown.json',{'until':self.cooldown,'url':url,'status':status})
                if attempt==2:raise Deferred('HTTP '+str(status)+' '+url,self.cooldown)
                continue
            if status!=200:raise ValueError('HTTP '+str(status)+' '+url)
            if image and not headers.get('content-type','').lower().startswith('image/'):raise ValueError('Response is not an image')
            sha=digest(body);p=blob_path(self.work,sha);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
            entry={'url':url,'sha':sha,'at':self.clock(),'type':headers.get('content-type','')};self.cache[key]=entry;atomic(self.work/'http-cache.json',self.cache);return body,entry
        raise Deferred('Request failed',self.clock()+300)
    def json(self,url,refresh=False):
        body,entry=self.get(url,refresh=refresh);x=json.loads(body)
        if isinstance(x,dict) and x.get('error'):raise ValueError('API error: '+str(x['error']))
        return x,entry
    def image(self,url):
        body,entry=self.get(url,image=True)
        import warnings
        from PIL import Image
        import io
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(body)) as im:
                if im.format not in ('JPEG','PNG','WEBP') or im.width*im.height>80000000:raise ValueError('Unsupported or oversized image')
                im.load()
                if im.width<self.policy['minWidth'] or im.height<self.policy['minHeight']:raise ValueError('Image too small')
                return {**entry,'width':im.width,'height':im.height,'format':im.format,'size':len(body)}
def chunks(out,records,limit=18000):
    out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True);index=[]
    for n,record in enumerate(records):
        raw=encoded(record);base=f'record-{n:05d}';names=[]
        if len(raw)<=limit:
            name=base+'.json';atomic(out/name,record);names=[name]
        else:
            pieces=[];part='';size=0
            for ch in raw.decode():
                length=len(ch.encode())
                if size+length>8000:pieces.append(part);part='';size=0
                part+=ch;size+=length
            if part:pieces.append(part)
            for j,text in enumerate(pieces):
                name=f'{base}-part-{j:03d}.json';value={'kind':'json-text-fragment','part':j+1,'total':len(pieces),'text':text};assert len(encoded(value))<=limit;atomic(out/name,value);names.append(name)
        index.append({'id':record.get('id',record.get('taskId',str(n))),'status':record.get('status'),'files':names})
    pages=[];page=[]
    for row in index:
        if page and len(encoded({'records':page+[row]}))>limit:
            name=f'index-{len(pages):03d}.json';atomic(out/name,{'records':page});pages.append(name);page=[]
        page.append(row)
    if page:
        name=f'index-{len(pages):03d}.json';atomic(out/name,{'records':page});pages.append(name)
    atomic(out/'manifest.json',{'schemaVersion':1,'count':len(records),'indexes':pages});return pages
