import copy,io,json,os,pathlib,shutil,subprocess,tempfile,time,unittest
from PIL import Image
from common import *
import adapters,collect,verify
class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=pathlib.Path(self.tmp.name);self.work=self.p/'work';self.policy=read(ROOT/'policy.json');self.policy.update(apiInterval=0,imageInterval=0,seconds=10000,maxRequests=10000)
        self.clock=time.time();self.calls=[];self.image=self.png();self.data={'objectID':1,'objectURL':'https://www.metmuseum.org/art/collection/search/1','title':'A painting','artistDisplayName':'Alice Painter','isPublicDomain':True,'primaryImage':'https://images.metmuseum.org/one.png','primaryImageSmall':'https://images.metmuseum.org/one.png','creditLine':'Museum gift'}
        self.task={'id':fingerprint(['alice','met:1']),'kind':'work','artistId':'alice','artist':'Алиса','aliases':['Alice Painter','Алиса'],'owner':'artists-batch-2.js','workKey':'met:1','title':'Картина','originalTitle':'A painting','source':self.data['objectURL'],'museum':'Met','medium':'Oil','attribution':'','image':'','zoom':''}
        self.cat={'schemaVersion':1,'snapshot':'fixture','records':[copy.deepcopy(self.task)],'tasks':[copy.deepcopy(self.task)]}
    def png(self,color='red',size=(600,400)):
        b=io.BytesIO();Image.new('RGB',size,color).save(b,'PNG');return b.getvalue()
    def transport(self,url,headers,limit):
        self.calls.append(url)
        if url.startswith('https://collectionapi.metmuseum.org/'):return 200,{'content-type':'application/json'},json.dumps(self.data).encode()
        if url.startswith('https://commons.wikimedia.org/'):return 200,{'content-type':'application/json'},b'{"query":{"pages":[]}}'
        if url.startswith('https://images.metmuseum.org/'):return 200,{'content-type':'image/png'},self.image
        raise AssertionError('Unexpected network request '+url)
    def http(self,transport=None):
        def sleep(s):self.clock+=s
        return HTTP(self.policy,self.work,transport or self.transport,lambda:self.clock,sleep)
    def collected(self):return collect.run('.',self.work,self.policy,catalogue=self.cat,http=self.http())
    def prepared(self):self.collected();return verify.prepare(self.work,self.policy,http=self.http())
    def site(self):
        repo=self.p/'site';base=repo/'games/painting';base.mkdir(parents=True);(base/'build-artists.mjs').write_text('/*reproduction-pipeline:hook-v1*/');return repo
    def test_direct_source_and_license(self):
        c=adapters.lookup(self.task,self.http())[0];self.assertEqual(c['objectId'],'1');self.assertTrue(c['rights']['documentedOpen']);self.assertEqual(c['basis'],'museum-primary')
    def test_rights_label_does_not_accept_nc(self):self.assertFalse(adapters.rights('CC BY-NC 4.0','https://creativecommons.org/licenses/by-nc/4.0/',author='x')['documentedOpen'])
    def test_restrictions_are_not_ignored(self):self.assertFalse(adapters.rights('CC BY 3.0','https://creativecommons.org/licenses/by/3.0/',author='x',restriction='ita-mibac')['documentedOpen'])
    def test_image_license_not_inherited_from_manifest(self):
        manifest={'rights':'https://creativecommons.org/publicdomain/zero/1.0/','items':[{'id':'canvas','label':{'en':['Front']},'items':[{'items':[{'body':{'id':'https://images.metmuseum.org/one.png','type':'Image'}}]}]}]}
        class H:
            def json(s,u):return manifest,{'url':u,'sha':'x','at':1}
        c=adapters.iiif_candidates(self.task,'https://www.metmuseum.org/manifest',H())[0];self.assertFalse(c['rights']['documentedOpen'])
    def test_positive_prepare_and_immutable_bytes(self):
        pkg,sha=self.prepared();self.assertEqual(len(pkg['entries']),1);asset=pkg['entries'][0]['preview']['sha'];self.assertEqual((self.work/'package/assets'/asset).read_bytes(),self.image);self.assertEqual(digest((self.work/'package/manifest.json').read_bytes()),sha)
    def test_unknown_rights_do_not_download_pixels(self):
        self.data['isPublicDomain']=False;self.collected();pkg,_=verify.prepare(self.work,self.policy,http=self.http());self.assertFalse(pkg['entries']);self.assertFalse(any(x.startswith('https://images.metmuseum.org') for x in self.calls))
    def test_creator_mismatch_not_auto_ready(self):
        self.data['artistDisplayName']='Bob Painter';pkg,_=self.prepared();self.assertFalse(pkg['entries'])
    def test_qualifier_not_auto_ready(self):
        self.data['artistPrefix']='circle of';pkg,_=self.prepared();self.assertFalse(pkg['entries']);self.assertEqual(read(self.work/'state.json')['tasks'][self.task['id']]['verification']['status'],'needs_editorial')
    def test_initial_registry_is_not_overwritten(self):
        self.task['owner']='index.html';self.cat['tasks']=[copy.deepcopy(self.task)];pkg,_=self.prepared();self.assertFalse(pkg['entries'])
    def test_no_work_selection_does_not_search_portraits(self):
        t={**self.task,'kind':'artist_selection','intentionalText':False};c,e,status=collect.collect_task(t,self.http());self.assertEqual(status,'needs_editorial');self.assertFalse(self.calls)
    def test_intentionally_text_only(self):
        t={**self.task,'kind':'artist_selection','intentionalText':True};self.assertEqual(collect.collect_task(t,self.http())[2],'intentional_text_only')
    def test_checkpoint_reuses_collected_task(self):
        self.collected();n=len(self.calls);self.collected();self.assertEqual(len(self.calls),n)
    def test_changed_source_requeues(self):
        state=self.collected();new=copy.deepcopy(self.cat);new['tasks'][0]['source']='https://www.metmuseum.org/art/collection/search/2';collect.sync(state,new);self.assertEqual(state['tasks'][self.task['id']]['status'],'queued')
    def test_bio_change_not_target_conflict(self):
        pkg,sha=self.prepared();cat=copy.deepcopy(self.cat);cat['records'][0]['bio']='New text';repo=self.site();r=verify.apply(self.work/'package',repo,sha,self.policy,catalogue=cat);self.assertEqual(r['added'],1);self.assertEqual(r['quizCardsModified'],False)
    def test_source_change_conflict_writes_nothing(self):
        _,sha=self.prepared();cat=copy.deepcopy(self.cat);cat['records'][0]['source']='https://www.metmuseum.org/art/collection/search/2';repo=self.site()
        with self.assertRaises(Conflict):verify.apply(self.work/'package',repo,sha,self.policy,catalogue=cat)
        self.assertFalse((repo/'games/painting/assets').exists())
    def test_apply_is_idempotent(self):
        _,sha=self.prepared();repo=self.site();a=verify.apply(self.work/'package',repo,sha,self.policy,catalogue=self.cat);b=verify.apply(self.work/'package',repo,sha,self.policy,catalogue=self.cat);self.assertEqual((a['added'],b['added'],b['unchanged']),(1,0,1));self.assertEqual(len(read(repo/'games/painting/data/reproductions/registry.json')['entries']),1)
    def test_existing_manual_image_protected(self):
        _,sha=self.prepared();cat=copy.deepcopy(self.cat);cat['records'][0]['image']='https://manual.test/image.jpg'
        with self.assertRaises(Conflict):verify.apply(self.work/'package',self.site(),sha,self.policy,catalogue=cat)
    def test_tampered_asset_rejected(self):
        pkg,sha=self.prepared();(self.work/'package/assets'/pkg['entries'][0]['preview']['sha']).write_bytes(b'changed')
        with self.assertRaises(ValueError):verify.apply(self.work/'package',self.site(),sha,self.policy,catalogue=self.cat)
    def test_tampered_manifest_rejected(self):
        _,sha=self.prepared();p=self.work/'package/manifest.json';p.write_bytes(p.read_bytes()+b' ')
        with self.assertRaises(ValueError):verify.apply(self.work/'package',self.site(),sha,self.policy,catalogue=self.cat)
    def test_missing_site_hook_is_explicit(self):
        _,sha=self.prepared();repo=self.site();(repo/'games/painting/build-artists.mjs').write_text('no hook')
        with self.assertRaises(Conflict):verify.apply(self.work/'package',repo,sha,self.policy,catalogue=self.cat)
    def test_budget_preserves_task(self):
        self.policy['maxRequests']=0;state=self.collected();self.assertEqual(state['tasks'][self.task['id']]['status'],'deferred');self.assertTrue((self.work/'progress.json').exists())
    def test_retry_after_is_not_shortened(self):
        count=0;start=self.clock
        def tr(url,h,l):
            nonlocal count;count+=1
            return (429,{'retry-after':'90'},b'') if count==1 else (200,{'content-type':'application/json'},b'{}')
        self.http(tr).json('https://commons.wikimedia.org/w/api.php');self.assertGreaterEqual(self.clock-start,90)
    def test_retry_after_over_budget_deferred(self):
        self.policy['seconds']=10
        with self.assertRaises(Deferred):self.http(lambda u,h,l:(429,{'retry-after':'90'},b'')).json('https://commons.wikimedia.org/w/api.php')
    def test_cache_deduplicates_tracking_urls(self):
        h=self.http();a=h.image('https://images.metmuseum.org/one.png?utm_source=a');n=len(self.calls);b=h.image('https://images.metmuseum.org/one.png?utm_source=b');self.assertEqual(a['sha'],b['sha']);self.assertEqual(len(self.calls),n)
    def test_private_redirect_is_rejected(self):
        with self.assertRaises(ValueError):self.http(lambda u,h,l:(302,{'location':'http://127.0.0.1/private'},b'')).get('https://www.uffizi.it/en/artworks/x')
    def test_corrupt_image_is_not_verified(self):
        self.image=b'not really a PNG';pkg,_=self.prepared();self.assertFalse(pkg['entries'])
    def test_report_chunks_are_reconstructible(self):
        records=[{'id':'unicode','text':'Я"\\'*30000}];out=self.p/'chunks';chunks(out,records);manifest=read(out/'manifest.json');idx=read(out/manifest['indexes'][0])['records'][0];joined=''.join(read(out/f)['text'] for f in idx['files']);self.assertEqual(json.loads(joined),records[0]);self.assertTrue(all(p.stat().st_size<=18000 for p in out.iterdir()))
    def test_symlink_asset_directory_rejected(self):
        repo=self.site();(repo/'games/painting/assets').symlink_to(repo/'games/painting')
        with self.assertRaises(ValueError):verify.safe_under(repo,repo/'games/painting/assets/test.jpg')
    def test_legacy_export_and_overlay_preserve_text(self):
        repo=self.p/'legacy';base=repo/'games/painting';base.mkdir(parents=True);(base/'index.html').write_text('const CARDS=[];const ARTISTS={};');batch="(()=>{console.log('not JSON');window.registerPaintingArtists({alice:{name:'Алиса',latin:'Alice Painter',bio:['Keep'],sources:[['Text','https://text.test']],works:[],pendingWorks:[{key:'met:1',title:'Work',source:'https://www.metmuseum.org/art/collection/search/1'}]}})})();";(base/'artists-batch-2.js').write_text(batch)
        first=collect.export(repo);self.assertEqual(len(first['tasks']),1);self.assertEqual(first['records'][0]['owner'],'artists-batch-2.js')
        media={'artistId':'alice','workKey':'met:1','expectedSource':self.task['source'],'image':'assets/reproductions/'+'a'*64+'.png','zoom':'assets/reproductions/'+'a'*64+'.png','imageSource':'https://www.metmuseum.org/1','license':'CC0','licenseURL':'https://creativecommons.org/publicdomain/zero/1.0/','creditLine':'Credit','identityBasis':'test','width':600,'height':400};atomic(base/'data/reproductions/registry.json',{'schemaVersion':1,'entries':[media]});second=collect.export(repo);self.assertEqual(second['records'][0]['image'],media['image']);self.assertFalse(second['tasks']);self.assertEqual((base/'artists-batch-2.js').read_text(),batch)
    def test_complete_offline_pipeline_and_build_hook(self):
        repo=self.p/'integrated';base=repo/'games/painting';base.mkdir(parents=True);(base/'index.html').write_text('const CARDS=[];const ARTISTS={}; /*artists.js-first*/');shutil.copy(ROOT/'tests/fixtures/builder.mjs',base/'build-artists.mjs')
        for f in ['install-catalogue-works.mjs','install-round-confirm.mjs','install-view-state.mjs']:(base/f).write_text('')
        batch="(()=>{window.registerPaintingArtists({alice:{name:'Алиса',latin:'Alice Painter',aliases:['Alice Painter','Алиса'],bio:['Preserve biography'],sources:[['Text','https://text.test']],works:[],pendingWorks:[{key:'met:1',title:'Work',source:'https://www.metmuseum.org/art/collection/search/1'}]}})})();";(base/'artists-batch-2.js').write_text(batch)
        dest=repo/'tools/reproductions';dest.mkdir(parents=True);shutil.copy(ROOT/'site-overlay.mjs',dest/'site-overlay.mjs')
        subprocess.run(['node',str(ROOT/'install-site-hook.mjs'),str(repo)],check=True,capture_output=True);installed=(base/'build-artists.mjs').read_bytes();subprocess.run(['node',str(ROOT/'install-site-hook.mjs'),str(repo)],check=True,capture_output=True);self.assertEqual(installed,(base/'build-artists.mjs').read_bytes())
        collect.run(repo,self.work,self.policy,http=self.http());pkg,sha=verify.prepare(self.work,self.policy,http=self.http());self.assertEqual(len(pkg['entries']),1);verify.apply(self.work/'package',repo,sha,self.policy);subprocess.run(['node','build-artists.mjs'],cwd=base,check=True,capture_output=True)
        js="import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';let all;const b={CARDS:[],console,document:{getElementById:()=>null},MutationObserver:class{observe(){}}};b.window=b;b.registerPaintingArtists=x=>all=x;vm.runInNewContext(fs.readFileSync('artists.js','utf8'),b);assert.equal(all.alice.bio[0],'Preserve biography');assert.equal(all.alice.pendingWorks.length,0);assert(all.alice.works[0].image.startsWith('assets/reproductions/'));"
        subprocess.run(['node','--input-type=module','-e',js],cwd=base,check=True,capture_output=True);self.assertEqual((base/'artists-batch-2.js').read_text(),batch)
    def test_export_failure_has_a_diagnostic(self):
        with self.assertRaises(Exception):collect.run(self.p/'missing',self.work,self.policy,http=self.http())
        self.assertEqual(read(self.work/'progress.json')['status'],'failed')
    def test_verifier_failure_has_a_diagnostic(self):
        with self.assertRaises(Exception):verify.prepare(self.work,self.policy,http=self.http())
        self.assertEqual(read(self.work/'verification-progress.json')['status'],'failed')
    def test_persist_copies_metadata_not_pixels(self):
        from persist import persist
        payload=self.p/'payload';atomic(payload/'state.json',{'schemaVersion':1});(payload/'package/assets').mkdir(parents=True);(payload/'package/assets/secret').write_bytes(b'pixels');dest=self.p/'checkpoint';self.assertEqual(persist(payload,dest),1);self.assertFalse((dest/'package').exists())
    def test_grouping_does_not_treat_catalogues_as_collections(self):
        self.assertEqual(adapters.museum('https://shop.uffizi.it/a.pdf'),'catalogues');self.assertEqual(adapters.museum('https://www.uffizi.it/en/events/a'),'uffizi-references')
    def test_aic_direct_adapter_and_all_creators(self):
        task={**self.task,'source':'https://www.artic.edu/artworks/7'}
        class H:
            def json(s,url):return {'data':{'id':7,'image_id':'img','title':'Work','is_public_domain':True,'artist_title':'Alice Painter','artist_titles':['Alice Painter','Bob Painter'],'artist_display':'Alice Painter and Bob Painter'},'config':{'iiif_url':'https://www.artic.edu/iiif/2'}},{'url':url,'sha':'x','at':1}
        c=adapters.lookup(task,H())[0];self.assertTrue(c['rights']['documentedOpen']);self.assertEqual(len(c['creators']),2);self.assertFalse(verify.creator_ok(task,c))
    def test_cma_description_qualifier_preserved(self):
        task={**self.task,'source':'https://www.clevelandart.org/art/1234.5'}
        class H:
            def json(s,url):return {'data':{'id':7,'accession_number':'1234.5','title':'Work','share_license_status':'CC0','images':{'web':{'url':'https://openaccess-cdn.clevelandart.org/x.jpg'}},'creators':[{'name':'Alice Painter','description':'Attributed to Alice Painter (French)'}]}},{'url':url,'sha':'x','at':1}
        c=adapters.lookup(task,H())[0];self.assertIn('Attributed',c['qualifier']);self.assertFalse(verify.creator_ok(task,c))
    def test_museum_html_is_candidate_not_identity_proof(self):
        class H:
            def get(s,url):return b'<meta property="og:image" content="/image.jpg"><meta property="og:title" content="Artwork">',{'url':url,'sha':'x','at':1}
        for url in ['https://www.uffizi.it/en/artworks/x','https://www.museidigenova.it/en/x','https://www.museodelprado.es/en/the-collection/art-work/x','https://www.rijksmuseum.nl/en/collection/x']:
            c=adapters.page_candidates({**self.task,'source':url},H())[0];self.assertEqual(c['basis'],'page-candidate');self.assertFalse(c['rights']['documentedOpen'])
    def test_public_domain_label_without_evidence_is_not_ready(self):self.assertFalse(adapters.rights('Public domain')['documentedOpen'])
    def test_html_report_escapes_metadata(self):
        state={'tasks':{'x':{'task':{'artist':'<script>evil</script>','title':'<img onerror=x>'},'status':'queued','candidates':[]}}}
        html=collect.html_report(state,self.policy);self.assertNotIn('<script>evil',html);self.assertIn('&lt;script&gt;evil',html)
    def test_html_report_does_not_embed_unknown_rights_images(self):
        c={'id':'x','title':'Candidate','source':'https://commons.wikimedia.org/wiki/File:X.jpg','image':'https://images.metmuseum.org/one.png','rights':{'documentedOpen':False}}
        state={'tasks':{'x':{'task':{'artist':'A','title':'T'},'status':'collected','candidates':[c]}}};self.assertNotIn('<img loading=',collect.html_report(state,self.policy))
    def test_cooldown_survives_between_tools(self):
        self.policy['seconds']=10;n=[0]
        def tr(u,h,l):n[0]+=1;return 429,{'retry-after':'90'},b''
        with self.assertRaises(Deferred):self.http(tr).json('https://commons.wikimedia.org/w/api.php')
        with self.assertRaises(Deferred):self.http(tr).json('https://commons.wikimedia.org/w/api.php')
        self.assertEqual(n[0],1)
    def test_optional_source_failure_preserves_primary_candidate(self):
        n=[0]
        def tr(u,h,l):
            if u.startswith('https://commons.wikimedia.org/'):n[0]+=1;return 429,{'retry-after':'90000'},b''
            return self.transport(u,h,l)
        c,errors,status=collect.collect_task(self.task,self.http(tr));self.assertEqual(status,'collected');self.assertEqual(c[0]['provider'],'met');self.assertTrue(errors[0]['retryAt'])
    def test_old_package_cannot_be_applied(self):
        _,sha=self.prepared();p=self.work/'package/manifest.json';x=read(p);x['createdAt']=time.time()-25*3600;atomic(p,x);sha=digest(p.read_bytes())
        with self.assertRaises(Conflict):verify.apply(self.work/'package',self.site(),sha,self.policy,catalogue=self.cat)
if __name__=='__main__':unittest.main()
