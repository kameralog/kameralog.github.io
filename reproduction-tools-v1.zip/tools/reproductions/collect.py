import argparse,collections,json,pathlib,subprocess,time
from common import *
import adapters
TARGET_FIELDS=('artistId','workKey','source','attribution','aliases')
def target_fp(task):return fingerprint({k:task.get(k) for k in TARGET_FIELDS})
def export(repo):
    p=subprocess.run(['node',str(ROOT/'legacy-export.mjs'),str(pathlib.Path(repo).resolve())],capture_output=True,check=True,timeout=60)
    return json.loads(p.stdout)
def sync(state,catalogue):
    state.setdefault('schemaVersion',1);state['snapshot']=catalogue['snapshot'];tasks=state.setdefault('tasks',{});active=set()
    for t in catalogue['tasks']:
        if t['id'] in active:raise ValueError('Duplicate task identity: '+t['id'])
        active.add(t['id']);fp=target_fp(t);old=tasks.get(t['id'])
        if not old or old.get('fingerprint')!=fp:tasks[t['id']]={'task':t,'fingerprint':fp,'status':'queued','nextAttemptAt':0,'attempts':0,'candidates':[]}
        else:old['task']=t
    for key,item in tasks.items():
        if key not in active:
            t=item['task'];bound=any(r.get('image') and r.get('artistId')==t.get('artistId') and (r.get('workKey')==t.get('workKey') if t.get('workKey') else r.get('source')==t.get('source')) for r in catalogue.get('records',[]));item['status']='already_bound' if bound else 'retired'
    return state
def collect_task(task,http):
    if task['kind']=='artist_selection':return [],[], 'intentional_text_only' if task.get('intentionalText') else 'needs_editorial'
    found=[];errors=[]
    for name,fn in [('museum',adapters.lookup),('museum-page',adapters.page_candidates),('commons',adapters.commons)]:
        try:found.extend(fn(task,http))
        except Deferred as e:
            if found:return list({c['id']:c for c in found}.values()),errors+[{'source':name,'error':str(e),'retryAt':e.retry_at}],'collected'
            raise
        except Exception as e:errors.append({'source':name,'error':str(e)})
    unique={c['id']:c for c in found}
    return list(unique.values()),errors,'collected' if unique else 'incomplete' if errors else 'not_found_in_checked_sources'
def html_report(state,policy):
    import html
    esc=lambda s:html.escape(str(s or ''),quote=True)
    rows=[]
    for id,item in state['tasks'].items():
        task=item['task'];cards=[]
        for c in item.get('candidates',[]):
            src=''
            try:src=validate_url(c.get('image',''),policy) if c.get('rights',{}).get('documentedOpen') else ''
            except ValueError:pass
            source=c.get('source','');u=__import__('urllib.parse',fromlist=['urlsplit']).urlsplit(source)
            link=source if u.scheme=='https' and not u.username and not u.password else ''
            cards.append('<article>'+('<img loading="lazy" referrerpolicy="no-referrer" src="'+esc(src)+'" alt="Кандидат на репродукцию">' if src else '<p>Предпросмотр не размещён: права или адрес требуют проверки.</p>')+'<h3>'+esc(c.get('title'))+'</h3><p>'+esc(c.get('rights',{}).get('name') or 'Права не подтверждены')+'</p><p><a href="'+esc(link)+'" target="_blank" rel="noopener noreferrer">Источник файла</a></p><small>'+esc(c['id'])+'</small></article>')
        rows.append('<details><summary>'+esc(task.get('artist'))+' — '+esc(task.get('title') or 'Произведение не выбрано')+' · '+esc(item['status'])+' · '+esc((item.get('verification') or {}).get('status','not_checked'))+'</summary><p>'+esc(item.get('errors',[]))+'</p>'+''.join(cards)+'</details>')
    return '<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Кандидаты репродукций</title><style>body{font:16px/1.5 system-ui;max-width:1200px;margin:auto;padding:24px}details{border:1px solid #aaa;margin:12px 0;padding:12px}article{display:inline-block;vertical-align:top;width:280px;margin:12px;overflow-wrap:anywhere}img{width:100%;height:220px;object-fit:contain}summary{cursor:pointer}</style><h1>Кандидаты репродукций</h1><p>Это отчёт, не панель записи в GitHub. Наличие изображения не означает подтверждённую атрибуцию. Сетевые превью могут быть недоступны в браузере. Секретов и токенов здесь нет.</p>'+''.join(rows)+'</html>'

def report(work,state):
    out=pathlib.Path(work)/'report';rows=[]
    for id,item in state['tasks'].items():rows.append({'id':id,'museum':adapters.museum(item['task'].get('source','')),'status':item['status'],'task':item['task'],'candidateIds':[c['id'] for c in item.get('candidates',[])],'verification':item.get('verification'),'errors':item.get('errors',[]),'nextAttemptAt':item.get('nextAttemptAt',0)})
    chunks(out/'tasks',rows)
    (out/'report.html').write_text(html_report(state,read(ROOT/'policy.json')),encoding='utf-8')
    candidates=[c for item in state['tasks'].values() for c in item.get('candidates',[])];chunks(out/'candidates',candidates)
    atomic(out/'summary.json',{'schemaVersion':1,'sourceSnapshot':state.get('snapshot'),'updatedAt':time.time(),'statuses':dict(collections.Counter(r['status'] for r in rows)),'candidateCount':len(candidates),'verificationStatuses':dict(collections.Counter((item.get('verification') or {}).get('status','not_checked') for item in state['tasks'].values())),'applicationFilesModified':False})
def run(repo,work,policy,museum='all',limit=0,refresh=False,catalogue=None,http=None):
    if limit<0:raise ValueError('Limit must be nonnegative')
    work=pathlib.Path(work);work.mkdir(parents=True,exist_ok=True)
    with locked(work):
        atomic(work/'progress.json',{'status':'starting','stage':'inventory','at':time.time()})
        try:
            loaded=read(work/'state.json',{})
            if loaded.get('schemaVersion',1)!=1:raise ValueError('Unsupported queue schema')
            state=sync(loaded,catalogue or export(repo))
        except BaseException as e:
            atomic(work/'progress.json',{'status':'failed','stage':'inventory','error':str(e),'at':time.time()});raise
        http=http or HTTP(policy,work);processed=0
        atomic(work/'progress.json',{'status':'running','processedThisRun':0,'sourceSnapshot':state['snapshot'],'at':time.time()});atomic(work/'state.json',state)
        try:
            for id,item in state['tasks'].items():
                if item['status']=='retired' or museum!='all' and adapters.museum(item['task'].get('source',''))!=museum:continue
                if not refresh and not item.get('errors') and item['status'] in ('collected','needs_editorial','intentional_text_only') and time.time()-item.get('collectedAt',0)<policy['cacheHours']*3600:continue
                if item.get('nextAttemptAt',0)>time.time():continue
                if limit and processed>=limit:break
                try:
                    candidates,errors,status=collect_task(item['task'],http);item.update(candidates=candidates,errors=errors,status=status,collectedAt=time.time(),verification=None,nextAttemptAt=min([e['retryAt'] for e in errors if e.get('retryAt')]+[time.time()+3600]) if errors else time.time()+3600 if status=='not_found_in_checked_sources' else 0)
                except Deferred as e:item.update(status='deferred',errors=[{'error':str(e)}],nextAttemptAt=e.retry_at)
                except Exception as e:item.update(status='failed',errors=[{'error':str(e)}],nextAttemptAt=time.time()+300)
                item['attempts']+=1;processed+=1;atomic(work/'state.json',state);atomic(work/'progress.json',{'status':'running','activeTask':id,'processedThisRun':processed,'requests':http.count,'at':time.time()})
                if http.clock()>=http.end or http.count>=policy['maxRequests']:break
        except BaseException as e:
            atomic(work/'progress.json',{'status':'failed','error':str(e),'processedThisRun':processed,'at':time.time()});raise
        else:atomic(work/'progress.json',{'status':'completed','processedThisRun':processed,'requests':http.count,'at':time.time()})
        finally:atomic(work/'state.json',state);report(work,state)
        return state
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',default='reproduction-state');p.add_argument('--museum',default='all');p.add_argument('--limit',type=int,default=0);p.add_argument('--refresh',action='store_true');p.add_argument('--policy',default=str(ROOT/'policy.json'));a=p.parse_args()
    try:s=run(a.repo,a.work,read(a.policy),a.museum,a.limit,a.refresh);print(json.dumps(read(pathlib.Path(a.work)/'report/summary.json'),ensure_ascii=False))
    except Exception as e:raise SystemExit(str(e))
